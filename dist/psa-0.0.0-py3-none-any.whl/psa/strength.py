# strength.py – core logic
def grade(pw: str) -> str:
    """return grade A–D"""
    score = 0
    score += 1 if len(pw) >= 12 else 0
    score += 1 if any(c.islower() for c in pw) and any(c.isupper() for c in pw) else 0
    score += 1 if any(c.isdigit() for c in pw) else 0
    score += 1 if any(c in "!@#$%^&*?" for c in pw) else 0
    return ["D", "C", "B", "A", "A"][score]
