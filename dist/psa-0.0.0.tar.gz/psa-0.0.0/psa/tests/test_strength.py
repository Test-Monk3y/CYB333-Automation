# test_strength.py
from psa.strength import grade

def test_short():
    assert grade("abc") == "D"

def test_mixed_case():
    assert grade("Password123") == "B"

def test_strong():
    assert grade("P@ssw0rdSecure!") == "A"
