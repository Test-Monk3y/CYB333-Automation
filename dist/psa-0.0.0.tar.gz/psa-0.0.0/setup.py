# setup shim
from setuptools import setup
setup()
# This file is a shim to allow the use of `python setup.py` commands
# It does not contain any package metadata or configuration.